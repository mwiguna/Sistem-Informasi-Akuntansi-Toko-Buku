<?php $__env->startSection('content'); ?>

    <main class="col-12 main">
        <div class="col-12 main-log">
            <form class="col-4 form-log" role="form" method="POST" action="<?php echo e(url('/login')); ?>">
                <?php echo e(csrf_field()); ?>


                <?php if($errors->has('email')): ?>
                    <div class="col-12 error"> <?php echo e($errors->first('email')); ?> </div>
                <?php endif; ?>

                <input id="email" type="email" class="col-12 intext" name="email" value="<?php echo e(old('email')); ?>" placeholder="E-mail" required>           
                <input id="password" type="password" class="col-12 intext" name="password" placeholder="Password" required>

                <div class="col-6 checkbox"><input type="checkbox" name="remember"> Remember Me </div>
                <input type="submit" class="col-4 insubmit" value="Login">
            </form>
        </div>
    </main>
                            
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>