<?php $__env->startSection('content'); ?>

    <form class="form-horizontal" role="form" method="POST" action="<?php echo e(url('/register')); ?>">
        <?php echo e(csrf_field()); ?>


        <input id="name" type="text" class="" name="name" value="<?php echo e(old('name')); ?>" required autofocus>

            <?php if($errors->has('name')): ?>
                <?php echo e($errors->first('name')); ?>

            <?php endif; ?>
                           
        <input id="email" type="email" class="" name="email" value="<?php echo e(old('email')); ?>" required>

            <?php if($errors->has('email')): ?>
                <?php echo e($errors->first('email')); ?>

            <?php endif; ?>
                            
        <input id="password" type="password" class="" name="password" required>

            <?php if($errors->has('password')): ?>
                <?php echo e($errors->first('password')); ?>

            <?php endif; ?>  
                          
        <input id="password-confirm" type="password" class="" name="password_confirmation" required>
                                
        <input type="submit" value="Register">
    </form>
               
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>