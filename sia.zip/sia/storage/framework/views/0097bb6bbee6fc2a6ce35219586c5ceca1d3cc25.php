<?php $__env->startSection('content'); ?>

    <main class="col-12">
        <?php if(Auth::user()->name == "admin"): ?> <?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php elseif(Auth::user()->name == "gudang"): ?> <?php echo $__env->make('layouts.gudang', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?> <?php echo $__env->make('layouts.pemilik', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>
        <div class="col-10 content">
            <div class="col-12 nota">
                <div class="col-12 title-content title-nota">Nota Pembelian</div>
                <table class="col-8" border="0">
                    <tr>
                        <td class="left" style="width: 20%">No. Faktur</td>
                        <td style="width: 1%">:</td>
                        <td class="left" style="width: 75%">#<?php echo e($notas[0]->faktur_id); ?></td>
                    </tr>
                    <tr>
                        <td class="left">Tanggal</td>
                        <td>:</td>
                        <td class="left"><?php echo e($controller->tanggal($notas[0]->created_at)); ?></td>
                    </tr>
                </table>
                <table bordercolor="#aaa" class="col-11 col-lg-9 col-md-7 col-sm-5 col-xs-3 tmargin" border="1px">
                    <tr>
                        <th style="width: 5%">No.</th>
                        <th style="width: 15%">Nama Barang</th>
                        <th>Harga</th>
                        <th style="width: 5%">Jumlah</th>
                        <th>Supplier</th>
                        <th>Total</th>
                    </tr>
                    <?php $i = 1; $total = 0; ?>
                    <?php $__currentLoopData = $notas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nota): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($i); ?>.</td>
                        <td><?php echo e($nota->nama); ?></td>
                        <td>Rp. <?php echo e(number_format($nota->harga, 0, ',', '.')); ?></td>
                        <td><?php echo e($nota->jumlah); ?></td>
                        <td><?php echo e($nota->supplier); ?></td>
                        <td>Rp. <?php echo e(number_format($nota->harga * $nota->jumlah, 0, ',', '.')); ?></td>
                    </tr>
                    <?php
                        $i++;
                        $total += $nota->harga * $nota->jumlah;
                    ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td colspan="5">Subtotal</td>
                        <td><b>Rp. <?php echo e(number_format($total, 0, ',', '.')); ?></b></td>
                    </tr>
                    
                </table>
            </div>
            <button type="button" class="col-2 insubmit inmini" onclick="window.print()">Cetak</button>

            <a href="/pembelian" class="col-2 insubmit inmini btn-green">Tambah Baru</a>
            <a href="/daftar/pembelian" class="col-2 insubmit inmini btn-green">Daftar</a>
            <a href="/deletePembelian/<?php echo e($notas[0]->faktur_id); ?>" class="col-2 insubmit inmini btn-green" onclick="return confirm('Yakin ini menghapus pembelian ini?')">Hapus</a>
        </div>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>