<?php $__env->startSection('content'); ?>

    <main class="col-12">
    <?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php if(Auth::user()->name == "admin"): ?>
        
        <div class="col-10 content">
            <div class="col-12 title-content">Tambah Penjualan</div>
            <form class="col-12 form-admin" onclick="return false">
                <input id="kode" type="text" class="col-4 intext inmini" placeholder="Kode Buku" required>        
                <input id="jumlah" type="text" class="col-3 intext inmini" placeholder="Jumlah" required>
                <input id="addBook" type="submit" class="col-2 insubmit inmini" value="Tambah">
            </form>            
            <button id="submit" type="button" class="col-2 insubmit inmini">Submit</button>
        </div>
        <?php endif; ?>
    </main>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>