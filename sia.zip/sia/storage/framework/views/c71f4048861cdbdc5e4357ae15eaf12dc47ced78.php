<?php $__env->startSection('content'); ?>

    <main class="col-12">

        <?php if(Auth::user()->name == "admin"): ?> <?php echo $__env->make('layouts.admin', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php elseif(Auth::user()->name == "gudang"): ?> <?php echo $__env->make('layouts.gudang', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php else: ?> <?php echo $__env->make('layouts.pemilik', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php endif; ?>

        <div class="col-10 content">
            <div class="col-12 title-content">Daftar Buku</div>
                
                <div class="col-12"><?php echo e(Session::get('msg')); ?></div>
                <input id="judul" type="text" class="col-4 intext inmini" placeholder="Cari Buku" required>
                <button type="button" id="btn-cari" class="col-2 insubmit inmini">Cari</button>
                <table bordercolor="#aaa" class="col-11 col-lg-9 col-md-7 col-sm-5 col-xs-3 tmargin" border="1px">
                    <tr>
                        <th style="width: 5%">No.</th>
                        <th style="width: 10%">Kode Buku</th>
                        <th style="width: 30%">Judul</th>
                        <th style="width: 15%">Penerbit</th>
                        <th style="width: 15%">Kategori</th>
                        <th>Harga</th>
                        <th>Stok</th>
                    </tr>
                    <?php $i = (!isset($_GET['page']) || $_GET['page'] == 1) ? 1 : $_GET['page'] * 10 - 9 ; ?>
                    <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($i); ?>.</td>
                        <td><a href="/buku/<?php echo e($book->id); ?>"><?php echo e($book->id); ?></a></td>
                        <td><?php echo e($book->judul); ?></td>
                        <td><a href="/buku/penerbit/<?php echo e($book->penerbit); ?>"><?php echo e($book->penerbit); ?></a></td>
                        <td><a href="/buku/kategori/<?php echo e($book->kategori); ?>"><?php echo e($book->kategori); ?></a></td>
                        <td>Rp. <?php echo e(number_format($book->harga, 0, ',', '.')); ?></td>
                        <td><?php echo e($book->stok); ?></td>
                    </tr>
                    <?php $i++; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </table>

                <div class="col-12"><?php echo e($books->links()); ?></div>

        </div>
    </main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>